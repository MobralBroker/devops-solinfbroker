**Manual Rápido: Subindo API Autenticação no Kubernetes com DBeaver**

**1. Deploy da API-Autenticação no Kubernetes:**

```bash
#  Acesse repositório com os arquivos de configuração
cd autenticacao-api

# Aplique os recursos no namespace "dev"
kubectl apply -f . -n dev







